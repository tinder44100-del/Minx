# =========================================
# 🚀 Main Backtester - Production Ready
# =========================================
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
import logging
import sys
from typing import Dict, List, Optional, Any

# Import our modules
from src.data_fetcher import XAUUSDDataFetcher, generate_realistic_market
from src.feature_engineering import (
    XAUUSDFeatureEngine, add_state_machine, add_target, get_feature_list
)
from src.model import XAUUSDModel, evaluate_model_performance
from src.trading_engine import TradingEngine

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class XAUUSDTradingSystem:
    """
    Complete XAUUSD trading system with:
    - Data fetching
    - Feature engineering
    - ML model training
    - Walk-forward backtesting
    - Trading simulation
    - Performance analysis
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.data_fetcher = XAUUSDDataFetcher(config)
        self.feature_engine = XAUUSDFeatureEngine(config)
        self.model = XAUUSDModel(config)
        self.trading_engine = TradingEngine(config)

        # Data
        self.df = None
        self.features = None
        self.results = None
        self.equity_df = None

        logger.info("XAUUSD Trading System initialized")

    def load_data(self, use_synthetic: bool = True, days: int = 60) -> pd.DataFrame:
        """
        Load market data from API or generate synthetic data.
        """
        logger.info("Loading market data...")

        if use_synthetic:
            logger.info("Using synthetic data for testing")
            self.df = generate_realistic_market(n=5000, config=self.config)
        else:
            try:
                self.df = self.data_fetcher.get_recent_data(days=days)
                if len(self.df) < 1000:
                    logger.warning("Insufficient API data, falling back to synthetic")
                    self.df = generate_realistic_market(n=5000, config=self.config)
            except Exception as e:
                logger.error(f"API error: {e}, using synthetic data")
                self.df = generate_realistic_market(n=5000, config=self.config)

        logger.info(f"Loaded {len(self.df)} candles")
        return self.df

    def prepare_features(self) -> pd.DataFrame:
        """
        Apply feature engineering to data.
        """
        logger.info("Preparing features...")

        # Add all features
        self.df = self.feature_engine.add_all_features(self.df)

        # Add state machine
        self.df = add_state_machine(self.df, self.config)

        # Add target
        self.df = add_target(
            self.df,
            look_forward=1,
            tp_pips=self.config.get('RISK', {}).get('take_profit_pips', 100),
            sl_pips=self.config.get('RISK', {}).get('stop_loss_pips', 50)
        )

        # Get feature list
        self.features = get_feature_list(self.config)

        # Filter to existing features
        self.features = [f for f in self.features if f in self.df.columns]

        logger.info(f"Feature engineering complete. {len(self.features)} features created")

        return self.df

    def train_model(self) -> XAUUSDModel:
        """
        Train the prediction model.
        """
        logger.info("Training model...")

        # Split data
        train_size = int(len(self.df) * 0.7)
        val_size = int(len(self.df) * 0.15)

        train_df = self.df.iloc[:train_size]
        val_df = self.df.iloc[train_size:train_size + val_size]
        test_df = self.df.iloc[train_size + val_size:]

        logger.info(f"Train: {len(train_df)}, Val: {len(val_df)}, Test: {len(test_df)}")

        # Train
        metrics = self.model.train(
            train_df[self.features],
            train_df['target'],
            val_df[self.features],
            val_df['target']
        )

        logger.info(f"Training complete. Validation accuracy: {metrics['validation']['accuracy']:.3f}")

        return self.model

    def run_backtest(self) -> Dict[str, Any]:
        """
        Run complete walk-forward backtest.
        """
        logger.info("=" * 60)
        logger.info("Starting Walk-Forward Backtest")
        logger.info("=" * 60)

        # Walk-forward parameters
        wf_config = self.config.get('WALK_FORWARD', {})
        train_window = wf_config.get('train_window', 1500)
        test_window = wf_config.get('test_window', 500)
        step = wf_config.get('step', 250)

        all_results = []
        all_equity = []

        total_windows = (len(self.df) - train_window - test_window) // step + 1

        for i, start in enumerate(range(0, len(self.df) - train_window - test_window, step)):
            train_end = start + train_window
            test_end = train_end + test_window

            train_df = self.df.iloc[start:train_end]
            test_df = self.df.iloc[train_end:test_end].copy()

            logger.info(f"\n{'=' * 40}")
            logger.info(f"Window {i + 1}/{total_windows}")
            logger.info(f"Train: {train_df['open_time'].iloc[0]} to {train_df['open_time'].iloc[-1]}")
            logger.info(f"Test:  {test_df['open_time'].iloc[0]} to {test_df['open_time'].iloc[-1]}")
            logger.info(f"{'=' * 40}")

            # Train model
            self.model.train(
                train_df[self.features],
                train_df['target']
            )

            # Predict on test set
            test_df['probability'] = self.model.predict_proba(test_df[self.features])[:, 1]

            # Reset trading engine for each window
            self.trading_engine = TradingEngine(self.config)

            # Run trading simulation
            for idx, row in test_df.iterrows():
                self.trading_engine.execute_bar(row)

            # Get results
            trades_df = self.trading_engine.get_trades_df()
            equity_df = self.trading_engine.get_equity_df()
            summary = self.trading_engine.get_summary()

            # Store results
            window_result = {
                'window': i + 1,
                'train_start': train_df['open_time'].iloc[0],
                'train_end': train_df['open_time'].iloc[-1],
                'test_start': test_df['open_time'].iloc[0],
                'test_end': test_df['open_time'].iloc[-1],
                'accuracy': self.model.metrics.get('validation', {}).get('accuracy', 0),
                'f1': self.model.metrics.get('validation', {}).get('f1', 0),
                'total_trades': summary.get('total_trades', 0),
                'win_rate': summary.get('win_rate', 0),
                'total_pnl': summary.get('total_pnl', 0),
                'profit_factor': summary.get('profit_factor', 0),
                'max_drawdown': summary.get('max_drawdown', 0)
            }

            all_results.append(window_result)

            if len(equity_df) > 0:
                equity_df['window'] = i + 1
                all_equity.append(equity_df)

            # Log summary
            logger.info(f"Window {i + 1} Results:")
            logger.info(f"  Accuracy: {window_result['accuracy']:.3f}")
            logger.info(f"  Trades: {window_result['total_trades']}")
            logger.info(f"  Win Rate: {window_result['win_rate']:.1%}")
            logger.info(f"  PnL: ${window_result['total_pnl']:.2f}")
            logger.info(f"  Profit Factor: {window_result['profit_factor']:.2f}")

        # Combine results
        self.results = pd.DataFrame(all_results)
        self.equity_df = pd.concat(all_equity, ignore_index=True)

        # Calculate overall statistics
        overall_stats = self._calculate_overall_stats()

        logger.info("\n" + "=" * 60)
        logger.info("BACKTEST COMPLETE - OVERALL RESULTS")
        logger.info("=" * 60)
        self._log_summary(overall_stats)

        return {
            'results': self.results,
            'equity': self.equity_df,
            'stats': overall_stats,
            'trades': self.trading_engine.get_trades_df()
        }

    def _calculate_overall_stats(self) -> Dict[str, Any]:
        """Calculate overall backtest statistics."""
        if self.results is None or len(self.results) == 0:
            return {}

        trades_df = self.trading_engine.get_trades_df()

        total_pnl = self.results['total_pnl'].sum()
        total_trades = self.results['total_trades'].sum()
        winning_trades = (trades_df['pnl'] > 0).sum() if len(trades_df) > 0 else 0
        losing_trades = (trades_df['pnl'] <= 0).sum() if len(trades_df) > 0 else 0

        total_wins = trades_df[trades_df['pnl'] > 0]['pnl'].sum() if len(trades_df) > 0 else 0
        total_losses = abs(trades_df[trades_df['pnl'] <= 0]['pnl'].sum()) if len(trades_df) > 0 else 0

        return {
            'total_windows': len(self.results),
            'total_trades': total_trades,
            'winning_trades': winning_trades,
            'losing_trades': losing_trades,
            'win_rate': winning_trades / total_trades if total_trades > 0 else 0,
            'total_pnl': total_pnl,
            'profit_factor': total_wins / total_losses if total_losses > 0 else 0,
            'avg_accuracy': self.results['accuracy'].mean(),
            'avg_f1': self.results['f1'].mean(),
            'avg_win_rate': self.results['win_rate'].mean(),
            'max_drawdown': self.results['max_drawdown'].max(),
            'sharpe_ratio': self._calculate_sharpe_ratio(),
            'sortino_ratio': self._calculate_sortino_ratio()
        }

    def _calculate_sharpe_ratio(self, risk_free: float = 0.0) -> float:
        """Calculate Sharpe ratio."""
        if self.equity_df is None or len(self.equity_df) == 0:
            return 0

        returns = self.equity_df['equity'].pct_change().dropna()
        if len(returns) == 0 or returns.std() == 0:
            return 0

        return (returns.mean() - risk_free) / returns.std() * np.sqrt(252 * 288)  # 5min bars

    def _calculate_sortino_ratio(self, risk_free: float = 0.0) -> float:
        """Calculate Sortino ratio."""
        if self.equity_df is None or len(self.equity_df) == 0:
            return 0

        returns = self.equity_df['equity'].pct_change().dropna()
        downside_returns = returns[returns < 0]

        if len(downside_returns) == 0 or downside_returns.std() == 0:
            return 0

        return (returns.mean() - risk_free) / downside_returns.std() * np.sqrt(252 * 288)

    def _log_summary(self, stats: Dict[str, Any]) -> None:
        """Log summary statistics."""
        logger.info(f"Total Windows: {stats.get('total_windows', 0)}")
        logger.info(f"Total Trades: {stats.get('total_trades', 0)}")
        logger.info(f"Win Rate: {stats.get('win_rate', 0):.1%}")
        logger.info(f"Total PnL: ${stats.get('total_pnl', 0):.2f}")
        logger.info(f"Profit Factor: {stats.get('profit_factor', 0):.2f}")
        logger.info(f"Avg Accuracy: {stats.get('avg_accuracy', 0):.3f}")
        logger.info(f"Sharpe Ratio: {stats.get('sharpe_ratio', 0):.2f}")
        logger.info(f"Max Drawdown: {stats.get('max_drawdown', 0):.1%}")

    def plot_results(self, save_path: str = None) -> None:
        """
        Plot backtest results.
        """
        if self.equity_df is None or len(self.equity_df) == 0:
            logger.warning("No equity data to plot")
            return

        fig, axes = plt.subplots(3, 1, figsize=(14, 12))

        # Equity Curve
        ax1 = axes[0]
        for window in self.equity_df['window'].unique():
            window_data = self.equity_df[self.equity_df['window'] == window]
            ax1.plot(window_data['timestamp'], window_data['equity'], linewidth=1)

        ax1.set_title('XAUUSD Trading System - Equity Curve (Walk-Forward)', fontsize=14)
        ax1.set_ylabel('Equity ($)')
        ax1.grid(True, alpha=0.3)
        ax1.axhline(y=self.config['ACCOUNT']['balance'], color='r', linestyle='--', alpha=0.5, label='Initial')

        # Drawdown
        ax2 = axes[1]
        for window in self.equity_df['window'].unique():
            window_data = self.equity_df[self.equity_df['window'] == window]
            ax2.fill_between(window_data['timestamp'], 0, window_data['drawdown'] * 100,
                           alpha=0.3)

        ax2.set_title('Drawdown (%)', fontsize=14)
        ax2.set_ylabel('Drawdown (%)')
        ax2.grid(True, alpha=0.3)

        # Window Performance
        ax3 = axes[2]
        if self.results is not None:
            bars = ax3.bar(range(len(self.results)), self.results['total_pnl'],
                          color=['green' if x > 0 else 'red' for x in self.results['total_pnl']])
            ax3.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
            ax3.set_title('Window Performance (PnL)', fontsize=14)
            ax3.set_xlabel('Window')
            ax3.set_ylabel('PnL ($)')
            ax3.grid(True, alpha=0.3)

        plt.tight_layout()

        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            logger.info(f"Results saved to {save_path}")

        plt.show()

    def plot_feature_importance(self, top_n: int = 20, save_path: str = None) -> None:
        """Plot feature importance."""
        importance = self.model.get_top_features(top_n)

        if importance is None or len(importance) == 0:
            logger.warning("No feature importance data")
            return

        fig, ax = plt.subplots(figsize=(10, 8))

        importance.head(top_n).plot(
            x='feature', y='importance', kind='barh', ax=ax, color='steelblue'
        )

        ax.set_title(f'Top {top_n} Feature Importance', fontsize=14)
        ax.set_xlabel('Importance')
        ax.invert_yaxis()

        plt.tight_layout()

        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')

        plt.show()

    def export_results(self, directory: str = 'results') -> None:
        """Export all results to CSV files."""
        import os
        os.makedirs(directory, exist_ok=True)

        if self.results is not None:
            self.results.to_csv(f'{directory}/backtest_results.csv', index=False)
            logger.info(f"Results saved to {directory}/backtest_results.csv")

        if self.equity_df is not None:
            self.equity_df.to_csv(f'{directory}/equity_curve.csv', index=False)
            logger.info(f"Equity saved to {directory}/equity_curve.csv")

        trades_df = self.trading_engine.get_trades_df()
        if len(trades_df) > 0:
            trades_df.to_csv(f'{directory}/trades.csv', index=False)
            logger.info(f"Trades saved to {directory}/trades.csv")

        if self.results is not None:
            stats = self._calculate_overall_stats()
            pd.DataFrame([stats]).to_csv(f'{directory}/summary_stats.csv', index=False)
            logger.info(f"Summary saved to {directory}/summary_stats.csv")


def main():
    """Main function to run the backtest."""
    import yaml

    # Load configuration
    config_path = 'config/config.yaml'
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)

    # Initialize system
    system = XAUUSDTradingSystem(config)

    # Load data
    system.load_data(use_synthetic=True, days=60)

    # Prepare features
    system.prepare_features()

    # Train model
    system.train_model()

    # Run backtest
    results = system.run_backtest()

    # Plot results
    system.plot_results(save_path='results/backtest_results.png')

    # Plot feature importance
    system.plot_feature_importance(save_path='results/feature_importance.png')

    # Export results
    system.export_results()

    return results


if __name__ == "__main__":
    results = main()
