# XAUUSD Trading System - Source Package
from .data_fetcher import XAUUSDDataFetcher, generate_realistic_market
from .feature_engineering import XAUUSDFeatureEngine, add_state_machine, add_target, get_feature_list
from .model import XAUUSDModel, evaluate_model_performance
from .trading_engine import TradingEngine, RiskManager, Position, Trade

__all__ = [
    'XAUUSDDataFetcher',
    'generate_realistic_market',
    'XAUUSDFeatureEngine',
    'add_state_machine',
    'add_target',
    'get_feature_list',
    'XAUUSDModel',
    'evaluate_model_performance',
    'TradingEngine',
    'RiskManager',
    'Position',
    'Trade'
]
