# =========================================
# 🤖 ML Model - Production Ready
# =========================================
import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import joblib
import logging
from typing import Dict, List, Tuple, Optional, Any
from datetime import datetime

logger = logging.getLogger(__name__)


class XAUUSDModel:
    """
    Production-ready ML model for XAUUSD prediction.
    Includes time-series cross-validation and feature importance.
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.model = None
        self.feature_importance = None
        self.metrics = {}
        self.best_params = None

        # Model parameters
        model_config = config.get('MODEL', {})
        self.params = {
            'n_estimators': model_config.get('n_estimators', 500),
            'learning_rate': model_config.get('learning_rate', 0.02),
            'max_depth': model_config.get('max_depth', 8),
            'min_child_samples': model_config.get('min_child_samples', 50),
            'subsample': model_config.get('subsample', 0.8),
            'colsample_bytree': model_config.get('colsample_bytree', 0.8),
            'reg_alpha': model_config.get('reg_alpha', 0.1),
            'reg_lambda': model_config.get('reg_lambda', 0.1),
            'class_weight': model_config.get('class_weight', 'balanced'),
            'random_state': 42,
            'n_jobs': -1,
            'verbosity': -1
        }

        logger.info(f"Model initialized with params: {self.params}")

    def train(self, X_train: pd.DataFrame, y_train: pd.Series,
              X_val: pd.DataFrame = None, y_val: pd.Series = None) -> Dict[str, Any]:
        """
        Train the model with optional validation data.
        """
        logger.info(f"Training model on {len(X_train)} samples...")

        # Create model
        self.model = LGBMClassifier(**self.params)

        # Train with early stopping if validation data provided
        if X_val is not None and y_val is not None:
            self.model.fit(
                X_train, y_train,
                eval_set=[(X_val, y_val)],
                callbacks=[
                    # Early stopping not directly supported, but we can track
                ]
            )
        else:
            self.model.fit(X_train, y_train)

        # Calculate feature importance
        self.feature_importance = pd.DataFrame({
            'feature': X_train.columns,
            'importance': self.model.feature_importances_
        }).sort_values('importance', ascending=False)

        # Calculate training metrics
        y_pred_train = self.model.predict(X_train)
        self.metrics['train'] = self._calculate_metrics(y_train, y_pred_train)

        # Calculate validation metrics if available
        if X_val is not None and y_val is not None:
            y_pred_val = self.model.predict(X_val)
            self.metrics['validation'] = self._calculate_metrics(y_val, y_pred_val)

        logger.info(f"Training complete. Metrics: {self.metrics}")

        return self.metrics

    def train_walk_forward(self, df: pd.DataFrame, features: List[str],
                          target_col: str = 'target') -> pd.DataFrame:
        """
        Walk-forward training for time series data.
        Uses expanding window with validation.
        """
        wf_config = self.config.get('WALK_FORWARD', {})
        train_window = wf_config.get('train_window', 1500)
        test_window = wf_config.get('test_window', 500)
        step = wf_config.get('step', 250)

        logger.info(f"Starting walk-forward training: train={train_window}, test={test_window}, step={step}")

        results = []
        equity_curves = []

        total_windows = (len(df) - train_window - test_window) // step + 1

        for i, start in enumerate(range(0, len(df) - train_window - test_window, step)):
            train_end = start + train_window
            test_end = train_end + test_window

            train_df = df.iloc[start:train_end]
            test_df = df.iloc[train_end:test_end].copy()

            # Train model
            self.train(
                train_df[features],
                train_df[target_col],
                test_df[features],
                test_df[target_col]
            )

            # Make predictions on test set
            test_df['prediction'] = self.model.predict(test_df[features])
            test_df['probability'] = self.model.predict_proba(test_df[features])[:, 1]

            # Calculate equity curve
            test_df = self._calculate_equity(test_df)

            results.append({
                'window': i + 1,
                'train_start': start,
                'train_end': train_end,
                'test_start': train_end,
                'test_end': test_end,
                'accuracy': self.metrics.get('validation', {}).get('accuracy', 0),
                'f1': self.metrics.get('validation', {}).get('f1', 0),
                'total_return': test_df['equity_curve'].iloc[-1] / test_df['equity_curve'].iloc[0] - 1,
                'max_drawdown': test_df['drawdown'].max()
            })

            equity_curves.append(test_df[['open_time', 'equity_curve', 'drawdown', 'prediction', 'probability']].copy())

            logger.info(f"Window {i + 1}/{total_windows}: Accuracy={results[-1]['accuracy']:.3f}, "
                       f"Return={results[-1]['total_return']:.3%}")

        results_df = pd.DataFrame(results)
        equity_df = pd.concat(equity_curves, ignore_index=True)

        return results_df, equity_df

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """Make predictions on new data."""
        if self.model is None:
            raise ValueError("Model not trained yet!")

        return self.model.predict(X)

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """Get prediction probabilities."""
        if self.model is None:
            raise ValueError("Model not trained yet!")

        return self.model.predict_proba(X)

    def get_top_features(self, n: int = 20) -> pd.DataFrame:
        """Get top N most important features."""
        if self.feature_importance is None:
            return pd.DataFrame()

        return self.feature_importance.head(n)

    def save_model(self, path: str) -> None:
        """Save model to disk."""
        joblib.dump({
            'model': self.model,
            'feature_importance': self.feature_importance,
            'metrics': self.metrics,
            'params': self.params
        }, path)
        logger.info(f"Model saved to {path}")

    def load_model(self, path: str) -> None:
        """Load model from disk."""
        data = joblib.load(path)
        self.model = data['model']
        self.feature_importance = data['feature_importance']
        self.metrics = data['metrics']
        self.params = data['params']
        logger.info(f"Model loaded from {path}")

    def _calculate_metrics(self, y_true: pd.Series, y_pred: np.ndarray) -> Dict[str, float]:
        """Calculate classification metrics."""
        return {
            'accuracy': accuracy_score(y_true, y_pred),
            'precision': precision_score(y_true, y_pred, zero_division=0),
            'recall': recall_score(y_true, y_pred, zero_division=0),
            'f1': f1_score(y_true, y_pred, zero_division=0),
            'confusion_matrix': confusion_matrix(y_true, y_pred).tolist()
        }

    def _calculate_equity(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate equity curve for backtest."""
        risk_config = self.config.get('RISK', {})
        signal_config = self.config.get('SIGNAL', {})

        no_trade_zone = signal_config.get('no_trade_zone', 0.10)
        entry_confidence = signal_config.get('entry_confidence', 0.55)

        # Generate signals
        df['signal'] = 0
        df.loc[df['probability'] > 0.5 + no_trade_zone / 2, 'signal'] = 1
        df.loc[df['probability'] < 0.5 - no_trade_zone / 2, 'signal'] = -1

        # Calculate returns
        df['strategy_return'] = df['signal'].shift(1) * df['return_1']

        # Add costs
        costs_config = self.config.get('COSTS', {})
        spread_pips = costs_config.get('spread_pips', 15)
        pip_value = 0.01
        spread_cost = spread_pips * pip_value / df['close'].iloc[0]

        df['strategy_return'] = df['strategy_return'] - spread_cost

        # Equity curve
        df['equity_curve'] = (1 + df['strategy_return'].fillna(0)).cumprod()
        df['equity_curve'] = df['equity_curve'] / df['equity_curve'].iloc[0]

        # Drawdown
        df['peak'] = df['equity_curve'].cummax()
        df['drawdown'] = (df['equity_curve'] - df['peak']) / df['peak']

        return df

    def hyperparameter_tuning(self, X: pd.DataFrame, y: pd.Series,
                            param_grid: Dict = None) -> Dict[str, Any]:
        """
        Simple hyperparameter tuning for LightGBM.
        Note: For production, consider using Optuna or similar.
        """
        if param_grid is None:
            param_grid = {
                'n_estimators': [300, 500, 700],
                'max_depth': [6, 8, 10],
                'learning_rate': [0.01, 0.02, 0.03],
                'min_child_samples': [30, 50, 70]
            }

        logger.info("Starting hyperparameter tuning...")

        best_score = 0
        best_params = self.params.copy()

        # Simple grid search (time-consuming for large grids)
        for n_est in param_grid.get('n_estimators', [500]):
            for depth in param_grid.get('max_depth', [8]):
                for lr in param_grid.get('learning_rate', [0.02]):
                    for min_child in param_grid.get('min_child_samples', [50]):
                        params = self.params.copy()
                        params['n_estimators'] = n_est
                        params['max_depth'] = depth
                        params['learning_rate'] = lr
                        params['min_child_samples'] = min_child

                        model = LGBMClassifier(**params)
                        model.fit(X, y)

                        # Use last 20% for validation
                        split_idx = int(len(X) * 0.8)
                        score = model.score(X.iloc[split_idx:], y.iloc[split_idx:])

                        if score > best_score:
                            best_score = score
                            best_params = params.copy()

                        logger.info(f"Params: n_est={n_est}, depth={depth}, lr={lr}, "
                                  f"min_child={min_child} -> Score={score:.4f}")

        self.best_params = best_params
        self.params.update(best_params)

        logger.info(f"Best params: {best_params}, Best score: {best_score:.4f}")

        return best_params


def evaluate_model_performance(results_df: pd.DataFrame) -> Dict[str, Any]:
    """
    Evaluate overall walk-forward performance.
    """
    summary = {
        'total_windows': len(results_df),
        'avg_accuracy': results_df['accuracy'].mean(),
        'avg_f1': results_df['f1'].mean(),
        'avg_return': results_df['total_return'].mean(),
        'median_return': results_df['total_return'].median(),
        'win_rate': (results_df['total_return'] > 0).mean(),
        'max_drawdown_avg': results_df['max_drawdown'].mean(),
        'sharpe_ratio': results_df['total_return'].mean() / (results_df['total_return'].std() + 1e-10)
    }

    return summary
