# =========================================
# 💰 Trading Engine - Production Ready
# =========================================
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)


@dataclass
class Position:
    """Trading position."""
    ticket: int
    symbol: str
    direction: int  # 1 = long, -1 = short
    entry_price: float
    current_price: float
    volume: float
    stop_loss: float
    take_profit: float
    entry_time: pd.Timestamp
    pnl: float = 0.0
    pnl_pips: float = 0.0
    is_closed: bool = False

    def update(self, current_price: float) -> None:
        """Update position with current price."""
        self.current_price = current_price

        if self.direction == 1:  # Long
            self.pnl = (current_price - self.entry_price) * self.volume * 100  # Gold lot size
            self.pnl_pips = (current_price - self.entry_price) / 0.01
        else:  # Short
            self.pnl = (self.entry_price - current_price) * self.volume * 100
            self.pnl_pips = (self.entry_price - current_price) / 0.01


@dataclass
class Trade:
    """Completed trade record."""
    ticket: int
    symbol: str
    direction: int
    entry_price: float
    exit_price: float
    volume: float
    entry_time: pd.Timestamp
    exit_time: pd.Timestamp
    pnl: float
    pnl_pips: float
    exit_reason: str  # 'sl', 'tp', 'signal', 'daily_limit'
    duration_bars: int


@dataclass
class EquitySnapshot:
    """Equity curve snapshot."""
    timestamp: pd.Timestamp
    equity: float
    balance: float
    drawdown: float
    open_positions: int
    daily_pnl: float


class RiskManager:
    """
    Risk management for XAUUSD trading.
    Handles position sizing, stop loss, take profit, and drawdown protection.
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.account_config = config.get('ACCOUNT', {})
        self.risk_config = config.get('RISK', {})
        self.costs_config = config.get('COSTS', {})

        # Account parameters
        self.initial_balance = self.account_config.get('balance', 10000)  # cents
        self.balance = self.initial_balance
        self.equity = self.initial_balance
        self.max_positions = self.account_config.get('max_positions', 1)
        self.max_daily_loss = self.account_config.get('max_daily_loss', 50)  # cents

        # Risk parameters
        self.max_risk_per_trade = self.risk_config.get('max_risk_per_trade', 0.02)
        self.max_drawdown = self.risk_config.get('max_drawdown', 0.10)
        self.stop_loss_pips = self.risk_config.get('stop_loss_pips', 50)
        self.take_profit_pips = self.risk_config.get('take_profit_pips', 100)
        self.trailing_stop = self.risk_config.get('trailing_stop', True)
        self.trailing_start = self.risk_config.get('trailing_start', 0.005)

        # Costs
        self.spread_pips = self.costs_config.get('spread_pips', 15)
        self.commission = self.costs_config.get('commission_per_lot', 3.5)
        self.slippage_pips = self.costs_config.get('slippage_pips', 5)

        # Gold-specific (XAUUSD)
        self.pip_size = 0.01
        self.lot_size = 0.01  # Mini lot for cent account
        self.pip_value = 0.10  # $0.10 per pip per 0.01 lot

        # State
        self.daily_loss = 0
        self.daily_start_balance = self.balance
        self.max_equity = self.balance
        self.peak_balance = self.balance

        logger.info(f"RiskManager initialized: Balance={self.balance}, "
                   f"Risk={self.max_risk_per_trade:.1%}, "
                   f"SL={self.stop_loss_pips}pips, TP={self.take_profit_pips}pips")

    def calculate_position_size(self, entry_price: float, stop_loss: float) -> float:
        """
        Calculate position size based on risk management rules.
        For cent account with $100 initial balance:
        - Risk 2% = $2 per trade
        - SL 50 pips = $0.50 per pip (0.01 lot)
        - Position = $2 / ($0.50 * 50) = 0.08 lot = 8 micro lots
        """
        risk_amount = self.balance * self.max_risk_per_trade
        sl_distance_pips = abs(entry_price - stop_loss) / self.pip_size

        if sl_distance_pips == 0:
            sl_distance_pips = self.stop_loss_pips

        # Pip value for micro lot (0.01)
        pip_value_micro = 0.01 * self.pip_size * 100  # ~$0.01 per pip for 0.01 lot

        # Calculate position size
        position_size = risk_amount / (sl_distance_pips * pip_value_micro)

        # Ensure within limits
        min_lot = 0.01
        max_lot = 0.10  # Conservative for cent account

        position_size = max(min_lot, min(max_lot, position_size))

        return round(position_size, 2)

    def check_entry_allowed(self, direction: int, signal_strength: float = 0.5) -> Tuple[bool, str]:
        """
        Check if entry is allowed based on risk rules.
        """
        # Check daily loss limit
        if self.daily_loss >= self.max_daily_loss:
            return False, f"Daily loss limit reached: {self.daily_loss}/{self.max_daily_loss}"

        # Check drawdown
        if self.equity <= self.peak_balance * (1 - self.max_drawdown):
            return False, f"Max drawdown reached: {self.equity}/{self.peak_balance}"

        # Check balance
        if self.balance < self.initial_balance * 0.5:
            return False, f"Balance too low: {self.balance}"

        # Check signal strength
        min_confidence = 0.52
        if signal_strength < min_confidence:
            return False, f"Signal strength too low: {signal_strength:.3f} < {min_confidence}"

        return True, "Allowed"

    def check_exit_allowed(self, position: Position) -> Tuple[bool, str]:
        """
        Check if exit is allowed based on risk rules.
        """
        # Check if SL or TP hit
        if position.direction == 1:  # Long
            if position.current_price <= position.stop_loss:
                return True, "Stop loss hit"
            if position.current_price >= position.take_profit:
                return True, "Take profit hit"
        else:  # Short
            if position.current_price >= position.stop_loss:
                return True, "Stop loss hit"
            if position.current_price <= position.take_profit:
                return True, "Take profit hit"

        return False, "No exit signal"

    def update_trailing_stop(self, position: Position) -> Optional[float]:
        """
        Update trailing stop if enabled.
        """
        if not self.trailing_stop:
            return None

        profit_pct = (position.current_price - position.entry_price) / position.entry_price

        if profit_pct >= self.trailing_start:
            # Trail stop at 50% of profit
            trail_distance = (position.current_price - position.entry_price) * 0.5
            new_sl = position.current_price - trail_distance

            if position.direction == 1:  # Long
                if new_sl > position.stop_loss:
                    return new_sl
            else:  # Short
                if new_sl < position.stop_loss:
                    return new_sl

        return None

    def update_daily(self) -> None:
        """Reset daily counters."""
        self.daily_loss = 0
        self.daily_start_balance = self.balance

    def record_trade_result(self, trade: Trade) -> None:
        """Record completed trade and update account."""
        self.balance += trade.pnl
        self.equity = self.balance

        if trade.pnl < 0:
            self.daily_loss += abs(trade.pnl)

        if self.balance > self.peak_balance:
            self.peak_balance = self.balance

        if self.balance > self.max_equity:
            self.max_equity = self.balance

    def get_drawdown(self) -> float:
        """Calculate current drawdown."""
        return (self.equity - self.peak_balance) / self.peak_balance if self.peak_balance > 0 else 0


class TradingEngine:
    """
    Production-ready trading engine for XAUUSD.
    Handles signal generation, order execution, and position management.
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.risk_manager = RiskManager(config)
        self.signal_config = config.get('SIGNAL', {})

        # State
        self.positions: Dict[int, Position] = {}
        self.trades: List[Trade] = []
        self.equity_curve: List[EquitySnapshot] = []
        self.ticket_counter = 0

        # Signal parameters
        self.no_trade_zone = self.signal_config.get('no_trade_zone', 0.10)
        self.entry_confidence = self.signal_config.get('entry_confidence', 0.55)
        self.exit_confidence = self.signal_config.get('exit_confidence', 0.48)

        # Costs
        self.costs_config = config.get('COSTS', {})
        self.spread_pips = self.costs_config.get('spread_pips', 15)

        logger.info("TradingEngine initialized")

    def generate_signal(self, probability: float, state: int,
                       momentum: float, volatility: float) -> int:
        """
        Generate trading signal based on probability and market conditions.

        Returns:
            1 = Long, -1 = Short, 0 = No trade
        """
        # Base signal from probability
        if probability > 0.5 + self.no_trade_zone / 2:
            base_signal = 1
        elif probability < 0.5 - self.no_trade_zone / 2:
            base_signal = -1
        else:
            return 0

        # State filter
        state_filter = True

        # High volatility states
        if state == 1:  # Manipulation - reduce size, more selective
            state_filter = probability > 0.55

        elif state == 2:  # Expansion - favor direction
            state_filter = probability > 0.52

        elif state == 0:  # Accumulation - wait for confirmation
            state_filter = probability > 0.55

        elif state == 3:  # Reversal - be cautious
            state_filter = probability > 0.58

        # Momentum filter
        momentum_filter = abs(momentum) > 0.001

        # Volatility filter (avoid extreme volatility)
        vol_percentile = volatility  # 0-1 scale
        vol_filter = vol_percentile < 0.95

        if state_filter and momentum_filter and vol_filter:
            return base_signal
        else:
            return 0

    def calculate_entry_price(self, direction: int, current_price: float,
                             spread_pips: float = None) -> float:
        """Calculate entry price with spread."""
        if spread_pips is None:
            spread_pips = self.spread_pips

        pip = 0.01
        spread_cost = spread_pips * pip

        if direction == 1:  # Long - buy at ask
            return current_price + spread_cost
        else:  # Short - sell at bid
            return current_price - spread_cost

    def calculate_stop_loss(self, direction: int, entry_price: float,
                           stop_loss_pips: float = None) -> float:
        """Calculate stop loss price."""
        if stop_loss_pips is None:
            stop_loss_pips = self.risk_manager.stop_loss_pips

        pip = 0.01
        sl_distance = stop_loss_pips * pip

        if direction == 1:  # Long - SL below entry
            return entry_price - sl_distance
        else:  # Short - SL above entry
            return entry_price + sl_distance

    def calculate_take_profit(self, direction: int, entry_price: float,
                             take_profit_pips: float = None) -> float:
        """Calculate take profit price."""
        if take_profit_pips is None:
            take_profit_pips = self.risk_manager.take_profit_pips

        pip = 0.01
        tp_distance = take_profit_pips * pip

        if direction == 1:  # Long - TP above entry
            return entry_price + tp_distance
        else:  # Short - TP below entry
            return entry_price - tp_distance

    def open_position(self, direction: int, entry_price: float,
                     stop_loss: float, take_profit: float,
                     timestamp: pd.Timestamp, volume: float = None,
                     probability: float = 0.5) -> Optional[Position]:
        """
        Open a new position.
        """
        # Check if entry allowed
        allowed, reason = self.risk_manager.check_entry_allowed(direction, probability)
        if not allowed:
            logger.debug(f"Entry not allowed: {reason}")
            return None

        # Check position limit
        if len(self.positions) >= self.risk_manager.max_positions:
            logger.debug("Max positions reached")
            return None

        # Calculate position size
        if volume is None:
            volume = self.risk_manager.calculate_position_size(entry_price, stop_loss)

        # Create position
        self.ticket_counter += 1
        position = Position(
            ticket=self.ticket_counter,
            symbol='XAUUSD',
            direction=direction,
            entry_price=entry_price,
            current_price=entry_price,
            volume=volume,
            stop_loss=stop_loss,
            take_profit=take_profit,
            entry_time=timestamp
        )

        self.positions[position.ticket] = position

        logger.info(f"Opened position: {position.ticket}, "
                   f"Direction={direction}, Entry={entry_price:.2f}, "
                   f"SL={stop_loss:.2f}, TP={take_profit:.2f}, "
                   f"Volume={volume:.2f}")

        return position

    def close_position(self, position: Position, exit_price: float,
                      exit_time: pd.Timestamp, reason: str) -> Trade:
        """
        Close a position and record the trade.
        """
        position.current_price = exit_price
        position.update(exit_price)

        # Create trade record
        trade = Trade(
            ticket=position.ticket,
            symbol=position.symbol,
            direction=position.direction,
            entry_price=position.entry_price,
            exit_price=exit_price,
            volume=position.volume,
            entry_time=position.entry_time,
            exit_time=exit_time,
            pnl=position.pnl,
            pnl_pips=position.pnl_pips,
            exit_reason=reason,
            duration_bars=0  # Would need to calculate
        )

        # Update risk manager
        self.risk_manager.record_trade_result(trade)

        # Remove position
        del self.positions[position.ticket]
        self.trades.append(trade)

        logger.info(f"Closed position: {position.ticket}, PnL={position.pnl:.2f}, Reason={reason}")

        return trade

    def update_positions(self, current_price: float, timestamp: pd.Timestamp) -> List[Trade]:
        """
        Update all open positions. Check for SL/TP hits and trailing stops.
        """
        closed_trades = []

        for ticket, position in list(self.positions.items()):
            position.current_price = current_price
            position.update(current_price)

            # Check trailing stop
            new_sl = self.risk_manager.update_trailing_stop(position)
            if new_sl is not None:
                position.stop_loss = new_sl
                logger.debug(f"Updated trailing SL: {position.ticket}, New SL={new_sl:.2f}")

            # Check for exit signals
            should_exit, reason = self.risk_manager.check_exit_allowed(position)

            if should_exit:
                trade = self.close_position(position, current_price, timestamp, reason)
                closed_trades.append(trade)

        return closed_trades

    def execute_bar(self, row: pd.Series) -> Dict[str, Any]:
        """
        Execute trading logic for a single bar.
        """
        results = {
            'signal': 0,
            'position_opened': False,
            'positions_closed': 0,
            'current_positions': len(self.positions)
        }

        timestamp = row['open_time']
        close_price = row['close']

        # Update existing positions
        if self.positions:
            closed = self.update_positions(close_price, timestamp)
            results['positions_closed'] = len(closed)

        # Generate signal for new position
        if not self.positions:
            signal = self.generate_signal(
                probability=row.get('probability', 0.5),
                state=row.get('state', 0),
                momentum=row.get('momentum_5', 0),
                volatility=row.get('range_percentile', 0.5)
            )

            results['signal'] = signal

            if signal != 0:
                # Calculate prices
                entry_price = self.calculate_entry_price(signal, close_price)
                stop_loss = self.calculate_stop_loss(signal, entry_price)
                take_profit = self.calculate_take_profit(signal, entry_price)
                probability = row.get('probability', 0.5)

                # Open position
                position = self.open_position(
                    direction=signal,
                    entry_price=entry_price,
                    stop_loss=stop_loss,
                    take_profit=take_profit,
                    timestamp=timestamp,
                    probability=probability
                )

                if position:
                    results['position_opened'] = True

        # Record equity snapshot
        self.record_equity(timestamp)

        return results

    def record_equity(self, timestamp: pd.Timestamp) -> None:
        """Record current equity state."""
        snapshot = EquitySnapshot(
            timestamp=timestamp,
            equity=self.risk_manager.equity,
            balance=self.risk_manager.balance,
            drawdown=self.risk_manager.get_drawdown(),
            open_positions=len(self.positions),
            daily_pnl=self.risk_manager.daily_loss
        )
        self.equity_curve.append(snapshot)

    def get_equity_df(self) -> pd.DataFrame:
        """Get equity curve as DataFrame."""
        if not self.equity_curve:
            return pd.DataFrame()

        return pd.DataFrame([
            {
                'timestamp': s.timestamp,
                'equity': s.equity,
                'balance': s.balance,
                'drawdown': s.drawdown,
                'open_positions': s.open_positions,
                'daily_pnl': s.daily_pnl
            }
            for s in self.equity_curve
        ])

    def get_trades_df(self) -> pd.DataFrame:
        """Get trades as DataFrame."""
        if not self.trades:
            return pd.DataFrame()

        return pd.DataFrame([
            {
                'ticket': t.ticket,
                'direction': 'Long' if t.direction == 1 else 'Short',
                'entry_price': t.entry_price,
                'exit_price': t.exit_price,
                'volume': t.volume,
                'entry_time': t.entry_time,
                'exit_time': t.exit_time,
                'pnl': t.pnl,
                'pnl_pips': t.pnl_pips,
                'exit_reason': t.exit_reason
            }
            for t in self.trades
        ])

    def get_summary(self) -> Dict[str, Any]:
        """Get trading summary statistics."""
        if not self.trades:
            return {
                'total_trades': 0,
                'win_rate': 0,
                'total_pnl': 0,
                'avg_win': 0,
                'avg_loss': 0
            }

        df = self.get_trades_df()

        winning_trades = df[df['pnl'] > 0]
        losing_trades = df[df['pnl'] <= 0]

        return {
            'total_trades': len(df),
            'winning_trades': len(winning_trades),
            'losing_trades': len(losing_trades),
            'win_rate': len(winning_trades) / len(df) if len(df) > 0 else 0,
            'total_pnl': df['pnl'].sum(),
            'avg_win': winning_trades['pnl'].mean() if len(winning_trades) > 0 else 0,
            'avg_loss': losing_trades['pnl'].mean() if len(losing_trades) > 0 else 0,
            'largest_win': winning_trades['pnl'].max() if len(winning_trades) > 0 else 0,
            'largest_loss': losing_trades['pnl'].min() if len(losing_trades) > 0 else 0,
            'max_drawdown': self.risk_manager.get_drawdown(),
            'final_balance': self.risk_manager.balance,
            'profit_factor': abs(winning_trades['pnl'].sum() / losing_trades['pnl'].sum()) if len(losing_trades) > 0 and losing_trades['pnl'].sum() != 0 else 0
        }
