# =========================================
# 📊 Data Fetcher - XAUUSD from Binance
# =========================================
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import time
import logging
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)


class XAUUSDDataFetcher:
    """
    Fetches real XAUUSD data from Binance exchange.
    Supports 5-minute timeframe for scalping/swing trading.
    """

    BASE_URL = "https://api.binance.com/api/v3"
    BASE_URL_TESTNET = "https://testnet.binance.vision/api/v3"

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.symbol = config.get('SYMBOL', 'XAUUSDT')
        self.timeframe = config.get('TIMEFRAME', '5m')
        self.limit = config.get('DATA_LIMIT', 1000)
        self.base_url = self.BASE_URL

        # Gold-specific parameters
        self.pip_size = 0.01  # Gold pip = $0.01
        self.tick_size = 0.01
        self.lot_size = 0.001  # Minimum lot size

        logger.info(f"Initialized XAUUSDDataFetcher for {self.symbol} on {self.timeframe}")

    def _make_request(self, endpoint: str, params: Dict = None) -> Optional[Dict]:
        """Make API request with retry logic."""
        import requests

        url = f"{self.base_url}/{endpoint}"
        max_retries = 3
        retry_delay = 1

        for attempt in range(max_retries):
            try:
                response = requests.get(url, params=params, timeout=30)
                response.raise_for_status()
                return response.json()
            except requests.exceptions.RequestException as e:
                logger.warning(f"Request attempt {attempt + 1} failed: {e}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (attempt + 1))
                else:
                    logger.error(f"All retry attempts failed for {endpoint}")
                    return None

        return None

    def get_klines(self, limit: int = None, start_time: int = None,
                   end_time: int = None) -> Optional[pd.DataFrame]:
        """
        Fetch OHLCV candlestick data from Binance.

        Args:
            limit: Number of candles to fetch (max 1000)
            start_time: Start time in milliseconds
            end_time: End time in milliseconds

        Returns:
            DataFrame with OHLCV data
        """
        if limit is None:
            limit = self.limit

        params = {
            'symbol': self.symbol,
            'interval': self.timeframe,
            'limit': limit
        }

        if start_time:
            params['startTime'] = start_time
        if end_time:
            params['endTime'] = end_time

        data = self._make_request('klines', params)

        if data is None:
            logger.error("Failed to fetch klines data")
            return None

        # Convert to DataFrame
        df = pd.DataFrame(data, columns=[
            'open_time', 'open', 'high', 'low', 'close', 'volume',
            'close_time', 'quote_volume', 'trades', 'taker_buy_base',
            'taker_buy_quote', 'ignore'
        ])

        # Convert types
        numeric_cols = ['open', 'high', 'low', 'close', 'volume', 'quote_volume']
        for col in numeric_cols:
            df[col] = pd.to_numeric(df[col], errors='coerce')

        # Convert timestamps
        df['open_time'] = pd.to_datetime(df['open_time'], unit='ms')
        df['close_time'] = pd.to_datetime(df['close_time'], unit='ms')

        # Drop unnecessary columns
        df = df.drop(['ignore'], axis=1)

        # Calculate spread (in pips)
        df['spread'] = (df['high'] - df['low']) / self.pip_size

        # Add day of week and hour for time-based features
        df['day_of_week'] = df['open_time'].dt.dayofweek
        df['hour'] = df['open_time'].dt.hour
        df['minute'] = df['open_time'].dt.minute

        logger.info(f"Fetched {len(df)} candles for {self.symbol}")

        return df

    def get_recent_data(self, days: int = 7) -> pd.DataFrame:
        """
        Fetch recent data for backtesting.

        Args:
            days: Number of days to fetch

        Returns:
            DataFrame with recent OHLCV data
        """
        end_time = datetime.now()
        start_time = end_time - timedelta(days=days)

        all_data = []

        # Binance limits to 1000 candles per request
        current_start = int(start_time.timestamp() * 1000)
        end_ms = int(end_time.timestamp() * 1000)

        while current_start < end_ms:
            batch = self.get_klines(limit=1000, start_time=current_start,
                                   end_time=end_ms)

            if batch is None or len(batch) == 0:
                break

            all_data.append(batch)
            current_start = int(pd.to_datetime(batch['close_time'].max()).timestamp() * 1000) + 1

            # Rate limiting
            time.sleep(0.2)

        if all_data:
            df = pd.concat(all_data, ignore_index=True)
            df = df.drop_duplicates(subset=['open_time']).sort_values('open_time')
            df = df.reset_index(drop=True)
            logger.info(f"Total data fetched: {len(df)} candles")
            return df
        else:
            logger.error("No data fetched")
            return pd.DataFrame()

    def get_spread_info(self) -> Dict[str, float]:
        """
        Get current spread information for XAUUSD.

        Returns:
            Dictionary with spread stats
        """
        recent = self.get_klines(limit=10)

        if recent is not None and len(recent) > 0:
            return {
                'current_spread': recent['spread'].iloc[-1],
                'avg_spread': recent['spread'].mean(),
                'max_spread': recent['spread'].max(),
                'min_spread': recent['spread'].min()
            }

        return {
            'current_spread': 15,
            'avg_spread': 15,
            'max_spread': 30,
            'min_spread': 10
        }


def generate_realistic_market(n: int = 10000, config: Dict = None) -> pd.DataFrame:
    """
    Generate realistic synthetic XAUUSD data for testing
    when API is not available.

    This simulates realistic gold market behavior including:
    - Multiple regime shifts (trending, ranging, volatile)
    - Realistic spread patterns
    - Liquidity sweeps
    - Session-based volatility changes
    """
    np.random.seed(42)

    if config is None:
        config = {}

    # Starting price around current gold price
    price = 2050.0

    # Trading session volatility patterns (gold is most volatile during NY/London overlap)
    session_vol = {
        'asian': 0.8,      # Low volatility
        'london': 1.2,     # Medium-high volatility
        'ny': 1.1,         # Medium-high volatility
        'overlap': 1.5     # Highest volatility
    }

    data = []

    for i in range(n):
        # Determine session based on synthetic hour
        hour = (i % 24)
        if 0 <= hour < 7:
            session = 'asian'
        elif 7 <= hour < 14:
            session = 'london'
        elif 14 <= hour < 21:
            session = 'ny'
        else:
            session = 'overlap'

        # Regime shifts (less frequent for realism)
        if i > 0 and np.random.rand() < 0.005:  # 0.5% chance
            regime = np.random.choice(['trend_up', 'trend_down', 'range', 'volatile'])
        else:
            regime = getattr(data[-1], 'regime', 'range') if data else 'range'

        # Calculate drift and volatility
        vol_multiplier = session_vol[session]

        if regime == 'trend_up':
            drift = 0.0001 * vol_multiplier
            vol = 0.008 * vol_multiplier
        elif regime == 'trend_down':
            drift = -0.0001 * vol_multiplier
            vol = 0.008 * vol_multiplier
        elif regime == 'volatile':
            drift = 0
            vol = 0.015 * vol_multiplier
        else:  # range
            drift = 0
            vol = 0.006 * vol_multiplier

        # Generate price
        shock = np.random.normal()
        open_price = price
        close_price = price * np.exp(drift + vol * shock)

        # Generate realistic high/low with liquidity sweeps
        range_pct = abs(close_price - open_price) / open_price

        # Sometimes generate wicks (liquidity sweeps)
        if np.random.rand() < 0.15:  # 15% chance of liquidity sweep
            wick_multiplier = np.random.uniform(1.5, 3.0)
        else:
            wick_multiplier = np.random.uniform(0.3, 0.8)

        high_price = max(open_price, close_price) * (1 + range_pct * wick_multiplier)
        low_price = min(open_price, close_price) * (1 - range_pct * wick_multiplier)

        # Realistic volume (gold has high volume during certain sessions)
        base_volume = 1000
        volume = base_volume * vol_multiplier * np.random.uniform(0.5, 2.0)

        # Calculate spread (wider during volatile periods)
        base_spread = 0.5  # $0.50 typical spread
        spread = base_spread * vol_multiplier * np.random.uniform(0.8, 1.5)

        data.append({
            'open_time': pd.Timestamp('2024-01-01') + pd.Timedelta(minutes=5 * i),
            'open': open_price,
            'high': high_price,
            'low': low_price,
            'close': close_price,
            'volume': volume,
            'regime': regime,
            'session': session,
            'spread': spread
        })

        price = close_price

    df = pd.DataFrame(data)

    # Add time features
    df['hour'] = df['open_time'].dt.hour
    df['day_of_week'] = df['open_time'].dt.dayofweek
    df['minute'] = df['open_time'].dt.minute

    # Drop the regime/session columns (they're for debugging)
    df = df.drop(['regime', 'session'], axis=1)

    return df


if __name__ == "__main__":
    # Test data fetcher
    logging.basicConfig(level=logging.INFO)

    # Try to fetch real data, fallback to synthetic
    try:
        fetcher = XAUUSDDataFetcher({'SYMBOL': 'XAUUSDT', 'TIMEFRAME': '5m', 'DATA_LIMIT': 100})
        df = fetcher.get_recent_data(days=3)
    except Exception as e:
        print(f"API fetch failed, using synthetic data: {e}")
        df = generate_realistic_market(n=5000)

    print(df.head())
    print(f"\nShape: {df.shape}")
    print(f"Columns: {df.columns.tolist()}")
