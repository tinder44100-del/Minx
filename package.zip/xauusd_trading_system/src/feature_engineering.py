# =========================================
# 📈 Feature Engineering - XAUUSD Optimized
# =========================================
import numpy as np
import pandas as pd
from typing import Dict, List, Optional
import logging

logger = logging.getLogger(__name__)


class XAUUSDFeatureEngine:
    """
    Advanced feature engineering for XAUUSD 5-minute trading.
    Features optimized for gold market characteristics.
    """

    def __init__(self, config: Dict = None):
        self.config = config or {}

        # Gold-specific parameters
        self.pip_size = 0.01  # Gold pip = $0.01

        # Lookback periods
        self.momentum_lookbacks = [5, 10, 20, 50]
        self.volatility_lookbacks = [14, 20, 50]
        self.structure_lookbacks = [5, 10, 20]

    def add_all_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Add all features to the dataframe."""
        logger.info("Adding features to dataframe...")

        df = self.add_price_features(df)
        df = self.add_momentum_features(df)
        df = self.add_volatility_features(df)
        df = self.add_structure_features(df)
        df = self.add_liquidity_features(df)
        df = self.add_session_features(df)

        # Drop NaN rows created by rolling calculations
        df = df.dropna().reset_index(drop=True)

        logger.info(f"Feature engineering complete. Shape: {df.shape}")
        return df

    def add_price_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Basic price-based features for XAUUSD.
        """
        # Returns
        for period in [1, 2, 3, 5]:
            df[f'return_{period}'] = df['close'].pct_change(period)

        # Candlestick patterns
        df['body'] = df['close'] - df['open']
        df['body_abs'] = np.abs(df['body'])

        df['upper_wick'] = df['high'] - df[['open', 'close']].max(axis=1)
        df['lower_wick'] = df[['open', 'close']].min(axis=1) - df['low']

        # Wick ratios
        df['wick_ratio'] = df['upper_wick'] / (df['lower_wick'] + 1e-10)
        df['body_ratio'] = df['body_abs'] / (df['high'] - df['low'] + 1e-10)

        # Candlestick type
        df['candle_type'] = np.where(df['body'] > 0, 1, -1)

        # Wick dominance (fisher indicator inspiration)
        total_wick = df['upper_wick'] + df['lower_wick'] + df['body_abs']
        df['upper_wick_pct'] = df['upper_wick'] / total_wick
        df['lower_wick_pct'] = df['lower_wick'] / total_wick

        # Range in pips
        df['range_pips'] = (df['high'] - df['low']) / self.pip_size
        df['body_pips'] = np.abs(df['body']) / self.pip_size

        # Price position within candle
        df['price_position'] = (df['close'] - df['low']) / (df['high'] - df['low'] + 1e-10)

        return df

    def add_momentum_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Momentum indicators optimized for XAUUSD.
        """
        # Price momentum
        for period in self.momentum_lookbacks:
            df[f'momentum_{period}'] = df['close'] - df['close'].shift(period)
            df[f'roc_{period}'] = (df['close'] - df['close'].shift(period)) / df['close'].shift(period)

        # RSI
        for period in [7, 14, 21]:
            delta = df['close'].diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()

            rs = gain / (loss + 1e-10)
            df[f'rsi_{period}'] = 100 - (100 / (1 + rs))

        # MACD
        exp1 = df['close'].ewm(span=12, adjust=False).mean()
        exp2 = df['close'].ewm(span=26, adjust=False).mean()
        df['macd'] = exp1 - exp2
        df['macd_signal'] = df['macd'].ewm(span=9, adjust=False).mean()
        df['macd_hist'] = df['macd'] - df['macd_signal']

        # Stochastic
        low_min = df['low'].rolling(window=14).min()
        high_max = df['high'].rolling(window=14).max()

        df['stoch_k'] = 100 * (df['close'] - low_min) / (high_max - low_min + 1e-10)
        df['stoch_d'] = df['stoch_k'].rolling(window=3).mean()

        # Momentum acceleration
        df['momentum_accel'] = df['momentum_5'] - df['momentum_5'].shift(1)

        # Price relative to moving averages
        for period in [10, 20, 50]:
            df[f'ma_{period}'] = df['close'].rolling(window=period).mean()
            df[f'price_vs_ma_{period}'] = (df['close'] - df[f'ma_{period}']) / df[f'ma_{period}']

        # EMA crossovers
        df['ema_8'] = df['close'].ewm(span=8, adjust=False).mean()
        df['ema_21'] = df['close'].ewm(span=21, adjust=False).mean()
        df['ema_cross'] = np.where(df['ema_8'] > df['ema_21'], 1, -1)
        df['ema_slope'] = (df['ema_8'] - df['ema_8'].shift(5)) / df['ema_8'].shift(5)

        return df

    def add_volatility_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Volatility features for XAUUSD - crucial for gold trading.
        """
        # ATR (Average True Range) - most important for gold
        df['tr'] = np.maximum(
            df['high'] - df['low'],
            np.maximum(
                np.abs(df['high'] - df['close'].shift(1)),
                np.abs(df['low'] - df['close'].shift(1))
            )
        )

        for period in self.volatility_lookbacks:
            df[f'atr_{period}'] = df['tr'].rolling(window=period).mean()
            df[f'volatility_{period}'] = df['return_1'].rolling(window=period).std()

        # ATR as percentage of price
        df['atr_pct'] = df['atr_14'] / df['close']

        # ATR relative to recent range
        df['atr_vs_range'] = df['atr_14'] / (df['high'] - df['low'] + 1e-10)

        # Bollinger Bands
        for period in [20]:
            df[f'bb_mid_{period}'] = df['close'].rolling(window=period).mean()
            df[f'bb_std_{period}'] = df['close'].rolling(window=period).std()

            df[f'bb_upper_{period}'] = df[f'bb_mid_{period}'] + 2 * df[f'bb_std_{period}']
            df[f'bb_lower_{period}'] = df[f'bb_mid_{period}'] - 2 * df[f'bb_std_{period}']

            df[f'bb_position_{period}'] = (df['close'] - df[f'bb_lower_{period}']) / \
                                          (df[f'bb_upper_{period}'] - df[f'bb_lower_{period}'] + 1e-10)

            df[f'bb_width_{period}'] = (df[f'bb_upper_{period}'] - df[f'bb_lower_{period}']) / \
                                        df[f'bb_mid_{period}']

        # Volatility percentile (useful for regime detection)
        df['range_percentile'] = df['range_pips'].rolling(window=50).apply(
            lambda x: pd.Series(x).rank(pct=True).iloc[-1], raw=False
        )

        # Relative volatility
        df['vol_ratio'] = df['volatility_14'] / (df['volatility_50'] + 1e-10)

        return df

    def add_structure_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Market structure features for identifying trends and ranges.
        """
        # Break of Structure (BOS)
        for period in self.structure_lookbacks:
            df[f'bos_up_{period}'] = (df['high'] > df['high'].rolling(period).max().shift(1)).astype(int)
            df[f'bos_down_{period}'] = (df['low'] < df['low'].rolling(period).min().shift(1)).astype(int)

        # Combined BOS signal
        df['bos_up'] = df['bos_up_10']
        df['bos_down'] = df['bos_down_10']

        # Higher High / Higher Low / Lower High / Lower Low
        df['hh'] = (df['high'] > df['high'].shift(1)) & (df['high'].shift(1) > df['high'].shift(2))
        df['ll'] = (df['low'] < df['low'].shift(1)) & (df['low'].shift(1) < df['low'].shift(2))
        df['lh'] = (df['high'] < df['high'].shift(1)) & (df['high'].shift(1) > df['high'].shift(2))
        df['hl'] = (df['low'] > df['low'].shift(1)) & (df['low'].shift(1) < df['low'].shift(2))

        # Swing highs and lows
        df['swing_high'] = df['high'].rolling(5).max()
        df['swing_low'] = df['low'].rolling(5).min()

        # Distance from swing points
        df['dist_from_swing_high'] = (df['swing_high'] - df['close']) / df['close']
        df['dist_from_swing_low'] = (df['close'] - df['swing_low']) / df['close']

        # Trend identification
        df['trend_up'] = ((df['close'] > df['close'].shift(5)) &
                         (df['close'].shift(5) > df['close'].shift(10))).astype(int)
        df['trend_down'] = ((df['close'] < df['close'].shift(5)) &
                            (df['close'].shift(5) < df['close'].shift(10))).astype(int)

        # Order blocks (simplified)
        df['ob_threshold'] = df['volatility_14'].rolling(20).mean()

        return df

    def add_liquidity_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Liquidity and order flow features for XAUUSD.
        """
        # Liquidity Sweep Detection
        # High breaks previous high but closes below (liquidity hunt)
        df['liq_sweep_high'] = (
            (df['high'] > df['high'].shift(1).rolling(5).max().shift(1)) &
            (df['close'] < df['open'])
        ).astype(int)

        df['liq_sweep_low'] = (
            (df['low'] < df['low'].shift(1).rolling(5).min().shift(1)) &
            (df['close'] > df['open'])
        ).astype(int)

        df['liq_sweep'] = df['liq_sweep_high'] + df['liq_sweep_low']

        # Range expansion (volatility breakout)
        df['range_expansion'] = (
            (df['range_pips'] > df['range_pips'].rolling(20).mean() * 1.5)
        ).astype(int)

        # Volume anomaly
        df['volume_ma'] = df['volume'].rolling(20).mean()
        df['volume_ratio'] = df['volume'] / (df['volume_ma'] + 1e-10)
        df['volume_spike'] = (df['volume_ratio'] > 2.0).astype(int)

        # Spread widening (low liquidity indicator)
        df['spread_ma'] = df.get('spread', pd.Series(15, index=df.index)).rolling(20).mean()
        df['spread_ratio'] = df.get('spread', pd.Series(15, index=df.index)) / (df['spread_ma'] + 1e-10)

        return df

    def add_session_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Trading session features - important for XAUUSD.
        Gold has different behavior during different sessions.
        """
        # Trading sessions (based on UTC)
        # Asian: 0-7 UTC
        # London: 7-14 UTC
        # New York: 14-21 UTC

        df['hour'] = df['open_time'].dt.hour

        df['session_asian'] = ((df['hour'] >= 0) & (df['hour'] < 7)).astype(int)
        df['session_london'] = ((df['hour'] >= 7) & (df['hour'] < 14)).astype(int)
        df['session_ny'] = ((df['hour'] >= 14) & (df['hour'] < 21)).astype(int)
        df['session_overlap'] = ((df['hour'] >= 13) & (df['hour'] < 17)).astype(int)  # London-NY overlap

        # Day of week
        df['day_of_week'] = df['open_time'].dt.dayofweek
        df['is_monday'] = (df['day_of_week'] == 0).astype(int)
        df['is_friday'] = (df['day_of_week'] == 4).astype(int)

        # Major news times (simplified - avoid high volatility periods)
        df['near_news'] = ((df['hour'] == 14) & (df['day_of_week'] == 2)).astype(int)  # Wednesday CPI

        return df


def add_state_machine(df: pd.DataFrame, config: Dict = None) -> pd.DataFrame:
    """
    Improved State Machine for XAUUSD market conditions.

    States:
    - 0: Accumulation/Distribution (low volatility, ranging)
    - 1: Manipulation/Liquidity Hunt (wicks, sweeps)
    - 2: Expansion/Trend (BOS, momentum)
    - 3: Reversal (potential turn)
    """
    if config is None:
        config = {}

    range_lookback = config.get('STATE_MACHINE', {}).get('range_lookback', 20)
    bos_lookback = config.get('STATE_MACHINE', {}).get('bos_lookback', 10)

    logger.info("Adding state machine features...")

    # Calculate range statistics
    df['range_mean'] = df['range_pips'].rolling(range_lookback).mean()
    df['range_std'] = df['range_pips'].rolling(range_lookback).std()
    df['range_upper'] = df['range_mean'] + df['range_std']
    df['range_lower'] = df['range_mean'] - df['range_std']

    # Volatility regime
    df['low_volatility'] = (df['range_pips'] < df['range_lower']).astype(int)
    df['high_volatility'] = (df['range_pips'] > df['range_upper']).astype(int)
    df['normal_volatility'] = 1 - df['low_volatility'] - df['high_volatility']

    # State assignment with proper priority
    df['state'] = -1

    # Priority 1: High volatility + BOS = Expansion/Trend
    expansion_mask = (
        (df['high_volatility'] == 1) &
        ((df['bos_up'] == 1) | (df['bos_down'] == 1))
    )
    df.loc[expansion_mask, 'state'] = 2

    # Priority 2: Liquidity sweep = Manipulation
    manipulation_mask = (
        (df['liq_sweep'] == 1) &
        (df['state'] == -1)
    )
    df.loc[manipulation_mask, 'state'] = 1

    # Priority 3: Reversal signals
    reversal_mask = (
        ((df['liq_sweep_high'] == 1) & (df['candle_type'] == 1)) |
        ((df['liq_sweep_low'] == 1) & (df['candle_type'] == -1)) |
        ((df['stoch_k'] < 20) & (df['stoch_k'] > df['stoch_k'].shift(1))) |
        ((df['stoch_k'] > 80) & (df['stoch_k'] < df['stoch_k'].shift(1)))
    )
    reversal_mask = reversal_mask & (df['state'] == -1)
    df.loc[reversal_mask, 'state'] = 3

    # Priority 4: Low volatility = Accumulation
    accumulation_mask = (df['state'] == -1)
    df.loc[accumulation_mask, 'state'] = 0

    # Fill any remaining NaN states
    df['state'] = df['state'].fillna(0).astype(int)

    # State features
    df['prev_state'] = df['state'].shift(1).fillna(-1).astype(int)

    # State transition encoding
    df['state_transition'] = (df['prev_state'] * 10 + df['state']).astype(int)

    # State duration
    df['state_block'] = (df['state'] != df['state'].shift()).cumsum()
    df['state_duration'] = df.groupby('state_block').cumcount()

    # State strength (based on range)
    df['state_strength'] = df['range_pips'] / (df['range_mean'] + 1e-10)

    # Transition scores (higher = more bullish)
    df['transition_score'] = 0

    # Bullish transitions
    bullish_mask = (df['prev_state'] == 0) & (df['state'] == 2)  # Accumulation -> Expansion
    df.loc[bullish_mask, 'transition_score'] = 3

    bullish_mask = (df['prev_state'] == 3) & (df['state'] == 2)  # Reversal -> Expansion
    df.loc[bullish_mask, 'transition_score'] = 2

    bullish_mask = (df['prev_state'] == 1) & (df['state'] == 2)  # Manipulation -> Expansion
    df.loc[bullish_mask, 'transition_score'] = 1

    # Bearish transitions
    bearish_mask = (df['prev_state'] == 2) & (df['state'] == 0)  # Expansion -> Accumulation
    df.loc[bearish_mask, 'transition_score'] = -3

    bearish_mask = (df['prev_state'] == 2) & (df['state'] == 1)  # Expansion -> Manipulation
    df.loc[bearish_mask, 'transition_score'] = -2

    # Consecutive same state
    df['consecutive_same_state'] = df.groupby('state_block').cumcount()

    # State momentum
    df['state_momentum'] = df.groupby('state_block')['close'].transform(
        lambda x: (x.iloc[-1] - x.iloc[0]) / x.iloc[0] if len(x) > 1 else 0
    )

    # State RSI (RSI within current state)
    df['state_rsi'] = df['rsi_14']

    return df


def add_target(df: pd.DataFrame, look_forward: int = 1,
               tp_pips: float = 100, sl_pips: float = 50) -> pd.DataFrame:
    """
    Create trading targets with realistic risk:reward.

    Args:
        df: DataFrame with OHLCV data
        look_forward: Number of periods to look ahead
        tp_pips: Take profit in pips
        sl_pips: Stop loss in pips
    """
    pip_value = 0.01

    # Future returns
    df['future_return'] = df['close'].shift(-look_forward) / df['close'] - 1

    # Simple target: will price go up?
    df['target'] = (df['close'].shift(-look_forward) > df['close']).astype(int)

    # TP/SL based targets
    tp_distance = tp_pips * pip_value
    sl_distance = sl_pips * pip_value

    # Calculate if TP or SL would be hit first
    future_highs = df['high'].rolling(look_forward).max().shift(-look_forward)
    future_lows = df['low'].rolling(look_forward).min().shift(-look_forward)

    tp_hit = (future_highs >= df['close'] + tp_distance).astype(int)
    sl_hit = (future_lows <= df['close'] - sl_distance).astype(int)

    # Combined target: 1 = TP hit first, 0 = SL hit first or neither
    df['target_tp_sl'] = ((tp_hit == 1) & (sl_hit == 0)).astype(int)

    # Confidence target: how far did price move?
    df['target_confidence'] = df['future_return']

    return df


def get_feature_list(config: Dict = None) -> List[str]:
    """
    Get the list of features to use for modeling.
    """
    if config is None:
        config = {}

    features = [
        # Price features
        'return_1', 'return_2', 'return_3', 'return_5',
        'body', 'body_abs', 'body_pips',
        'upper_wick', 'lower_wick', 'wick_ratio', 'body_ratio',
        'upper_wick_pct', 'lower_wick_pct',
        'candle_type', 'price_position',

        # Momentum features
        'momentum_5', 'momentum_10', 'momentum_20', 'momentum_50',
        'roc_5', 'roc_10', 'roc_20',
        'rsi_7', 'rsi_14', 'rsi_21',
        'macd', 'macd_signal', 'macd_hist',
        'stoch_k', 'stoch_d',
        'momentum_accel',
        'price_vs_ma_10', 'price_vs_ma_20', 'price_vs_ma_50',
        'ema_cross', 'ema_slope',

        # Volatility features
        'tr', 'atr_14', 'atr_20', 'atr_50',
        'volatility_14', 'volatility_20', 'volatility_50',
        'atr_pct', 'atr_vs_range',
        'bb_position_20', 'bb_width_20',
        'range_percentile', 'vol_ratio',

        # Structure features
        'bos_up', 'bos_down',
        'hh', 'll', 'lh', 'hl',
        'dist_from_swing_high', 'dist_from_swing_low',
        'trend_up', 'trend_down',

        # Liquidity features
        'liq_sweep_high', 'liq_sweep_low', 'liq_sweep',
        'range_expansion', 'volume_ratio', 'volume_spike',

        # Session features
        'session_asian', 'session_london', 'session_ny', 'session_overlap',
        'is_monday', 'is_friday',

        # State features
        'state', 'prev_state', 'state_transition',
        'state_duration', 'state_strength', 'transition_score',
        'consecutive_same_state', 'state_momentum', 'state_rsi',
        'low_volatility', 'high_volatility', 'normal_volatility'
    ]

    return features
